## Le modèle de boite
http://www-sop.inria.fr/members/Sylvain.Chevillard/fr.selfhtml.org/css/formats/affichage/modele_boite.png

## Le inline-block
http://fr.learnlayout.com/inline-block.html

## La propriété vertical-align
https://developer.mozilla.org/fr/docs/Web/CSS/vertical-align

## La propriété min-width
https://developer.mozilla.org/fr/docs/Web/CSS/min-width

## La propriété line-height
https://developer.mozilla.org/fr/docs/Web/CSS/line-height

## La propriété border
https://developer.mozilla.org/fr/docs/Web/CSS/border

## La propriété list-style-type
https://developer.mozilla.org/fr/docs/Web/CSS/list-style-type

## Les tableaux en HTML
https://openclassrooms.com/courses/apprenez-a-creer-votre-site-web-avec-html5-et-css3/les-tableaux-1

## Les formulaires en HTML
https://openclassrooms.com/courses/apprenez-a-creer-votre-site-web-avec-html5-et-css3/les-formulaires-8

## La propriété border-collapse
https://developer.mozilla.org/fr/docs/Web/CSS/border-collapse

## Sélecteur d'attribut
https://developer.mozilla.org/fr/docs/Web/CSS/S%C3%A9lecteurs_d_attribut

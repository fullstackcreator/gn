# INSTRUCTIONS
Construire un site avec du jQuery et de la vidéo

## HTML
- Utilisation du reset.css ou du normalize.css
- Utilisation du plugin jQuery [Flexslider](https://www.woothemes.com/flexslider/) :
    - cliquer sur ce lien
    - télécharger le plugin
    - suivre les instructions (Step 1 à 3)
    - Attention à l'étape 3, si utilisation de jQuery > 1.8 utiliser .on('load') et non l'alias .load()

## CSS
- Largeur limité à 1500px maximum pour certains éléments
- Taille de la police :
    - nav : 2.5rem
    - h1 : 4rem
    - h2 : 3rem
    - titres vignette : 2.5rem
- Police utilisé : "Bodega Sans"
- Réussir à créer les espaces entre chaque vignette "Moto" de manière la plus simple possible (utilisation des pseudo classe)

# BONUS
Trouver le moyen de désactiver les fleches directionnelles dans le FlexSlider en passant par le JS (Step 4)
